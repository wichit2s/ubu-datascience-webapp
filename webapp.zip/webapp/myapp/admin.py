from django.contrib import admin

from .models import PrimeMinister

# Register your models here.
admin.site.register(PrimeMinister)