from django.apps import AppConfig


class IrisappConfig(AppConfig):
    name = 'irisapp'
